<?php
class Member {
    private $conn;
    private $table = 'members';

    public $member_id;
    public $first_name;
    public $last_name;
    public $date_of_birth;
    public $gender;
    public $pin_number;
    public $address;
    public $phone;
    public $email;
    public $occupation;
    public $employer;
    public $membership_category;
    public $proof_document;
    public $preferred_activities;
    public $medical_conditions;
    public $emergency_contact_name;
    public $emergency_contact_phone;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = 'SELECT * FROM ' . $this->table . ' ORDER BY last_name, first_name';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single() {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE member_id = ? LIMIT 1';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->member_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row) {
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->date_of_birth = $row['date_of_birth'];
            $this->gender = $row['gender'];
            $this->pin_number = $row['pin_number'];
            $this->address = $row['address'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->occupation = $row['occupation'];
            $this->employer = $row['employer'];
            $this->membership_category = $row['membership_category'];
            $this->proof_document = $row['proof_document'];
            $this->preferred_activities = $row['preferred_activities'];
            $this->medical_conditions = $row['medical_conditions'];
            $this->emergency_contact_name = $row['emergency_contact_name'];
            $this->emergency_contact_phone = $row['emergency_contact_phone'];
            $this->status = $row['status'];
            return true;
        }
        return false;
    }

    public function create() {
        $query = 'INSERT INTO ' . $this->table . ' 
            SET 
                first_name = :first_name,
                last_name = :last_name,
                date_of_birth = :date_of_birth,
                gender = :gender,
                pin_number = :pin_number,
                address = :address,
                phone = :phone,
                email = :email,
                occupation = :occupation,
                employer = :employer,
                membership_category = :membership_category,
                proof_document = :proof_document,
                preferred_activities = :preferred_activities,
                medical_conditions = :medical_conditions,
                emergency_contact_name = :emergency_contact_name,
                emergency_contact_phone = :emergency_contact_phone,
                status = :status';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->first_name = htmlspecialchars(strip_tags($this->first_name));
        $this->last_name = htmlspecialchars(strip_tags($this->last_name));
        $this->date_of_birth = htmlspecialchars(strip_tags($this->date_of_birth));
        $this->gender = htmlspecialchars(strip_tags($this->gender));
        $this->pin_number = htmlspecialchars(strip_tags($this->pin_number));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->occupation = htmlspecialchars(strip_tags($this->occupation));
        $this->employer = htmlspecialchars(strip_tags($this->employer));
        $this->membership_category = htmlspecialchars(strip_tags($this->membership_category));
        $this->proof_document = htmlspecialchars(strip_tags($this->proof_document));
        $this->preferred_activities = htmlspecialchars(strip_tags($this->preferred_activities));
        $this->medical_conditions = htmlspecialchars(strip_tags($this->medical_conditions));
        $this->emergency_contact_name = htmlspecialchars(strip_tags($this->emergency_contact_name));
        $this->emergency_contact_phone = htmlspecialchars(strip_tags($this->emergency_contact_phone));
        $this->status = htmlspecialchars(strip_tags($this->status));

        // Bind data
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':date_of_birth', $this->date_of_birth);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':pin_number', $this->pin_number);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':occupation', $this->occupation);
        $stmt->bindParam(':employer', $this->employer);
        $stmt->bindParam(':membership_category', $this->membership_category);
        $stmt->bindParam(':proof_document', $this->proof_document);
        $stmt->bindParam(':preferred_activities', $this->preferred_activities);
        $stmt->bindParam(':medical_conditions', $this->medical_conditions);
        $stmt->bindParam(':emergency_contact_name', $this->emergency_contact_name);
        $stmt->bindParam(':emergency_contact_phone', $this->emergency_contact_phone);
        $stmt->bindParam(':status', $this->status);

        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function update() {
        $query = 'UPDATE ' . $this->table . ' 
            SET 
                first_name = :first_name,
                last_name = :last_name,
                date_of_birth = :date_of_birth,
                gender = :gender,
                pin_number = :pin_number,
                address = :address,
                phone = :phone,
                email = :email,
                occupation = :occupation,
                employer = :employer,
                membership_category = :membership_category,
                proof_document = :proof_document,
                preferred_activities = :preferred_activities,
                medical_conditions = :medical_conditions,
                emergency_contact_name = :emergency_contact_name,
                emergency_contact_phone = :emergency_contact_phone,
                status = :status
            WHERE member_id = :member_id';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->first_name = htmlspecialchars(strip_tags($this->first_name));
        $this->last_name = htmlspecialchars(strip_tags($this->last_name));
        $this->date_of_birth = htmlspecialchars(strip_tags($this->date_of_birth));
        $this->gender = htmlspecialchars(strip_tags($this->gender));
        $this->pin_number = htmlspecialchars(strip_tags($this->pin_number));
        $this->address = htmlspecialchars(strip_tags($this->address));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->occupation = htmlspecialchars(strip_tags($this->occupation));
        $this->employer = htmlspecialchars(strip_tags($this->employer));
        $this->membership_category = htmlspecialchars(strip_tags($this->membership_category));
        $this->proof_document = htmlspecialchars(strip_tags($this->proof_document));
        $this->preferred_activities = htmlspecialchars(strip_tags($this->preferred_activities));
        $this->medical_conditions = htmlspecialchars(strip_tags($this->medical_conditions));
        $this->emergency_contact_name = htmlspecialchars(strip_tags($this->emergency_contact_name));
        $this->emergency_contact_phone = htmlspecialchars(strip_tags($this->emergency_contact_phone));
        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->member_id = htmlspecialchars(strip_tags($this->member_id));

        // Bind data
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':date_of_birth', $this->date_of_birth);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':pin_number', $this->pin_number);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':occupation', $this->occupation);
        $stmt->bindParam(':employer', $this->employer);
        $stmt->bindParam(':membership_category', $this->membership_category);
        $stmt->bindParam(':proof_document', $this->proof_document);
        $stmt->bindParam(':preferred_activities', $this->preferred_activities);
        $stmt->bindParam(':medical_conditions', $this->medical_conditions);
        $stmt->bindParam(':emergency_contact_name', $this->emergency_contact_name);
        $stmt->bindParam(':emergency_contact_phone', $this->emergency_contact_phone);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':member_id', $this->member_id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = 'DELETE FROM ' . $this->table . ' WHERE member_id = :member_id';
        $stmt = $this->conn->prepare($query);
        $this->member_id = htmlspecialchars(strip_tags($this->member_id));
        $stmt->bindParam(':member_id', $this->member_id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function search($keywords) {
        $query = 'SELECT * FROM ' . $this->table . ' 
            WHERE 
                first_name LIKE ? OR 
                last_name LIKE ? OR 
                email LIKE ? OR 
                phone LIKE ? OR 
                pin_number LIKE ?
            ORDER BY last_name, first_name';

        $stmt = $this->conn->prepare($query);
        $keywords = htmlspecialchars(strip_tags($keywords));
        $keywords = "%{$keywords}%";

        $stmt->bindParam(1, $keywords);
        $stmt->bindParam(2, $keywords);
        $stmt->bindParam(3, $keywords);
        $stmt->bindParam(4, $keywords);
        $stmt->bindParam(5, $keywords);

        $stmt->execute();
        return $stmt;
    }

    public function get_by_category($category) {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE membership_category = ? ORDER BY last_name, first_name';
        $stmt = $this->conn->prepare($query);
        $category = htmlspecialchars(strip_tags($category));
        $stmt->bindParam(1, $category);
        $stmt->execute();
        return $stmt;
    }
}
?>