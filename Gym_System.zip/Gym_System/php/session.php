<?php
class Session {
    private $conn;
    private $table = 'sessions';

    public $session_id;
    public $trainer_id;
    public $session_type;
    public $activity_type;
    public $max_participants;
    public $start_time;
    public $end_time;
    public $location;
    public $status;
    public $notes;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = 'SELECT 
            s.session_id, 
            s.trainer_id, 
            t.first_name as trainer_first_name, 
            t.last_name as trainer_last_name,
            s.session_type, 
            s.activity_type, 
            s.max_participants, 
            s.start_time, 
            s.end_time, 
            s.location, 
            s.status, 
            s.notes
        FROM ' . $this->table . ' s
        LEFT JOIN trainers t ON s.trainer_id = t.trainer_id
        ORDER BY s.start_time DESC';

        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single() {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE session_id = ? LIMIT 1';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->session_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row) {
            $this->trainer_id = $row['trainer_id'];
            $this->session_type = $row['session_type'];
            $this->activity_type = $row['activity_type'];
            $this->max_participants = $row['max_participants'];
            $this->start_time = $row['start_time'];
            $this->end_time = $row['end_time'];
            $this->location = $row['location'];
            $this->status = $row['status'];
            $this->notes = $row['notes'];
            return true;
        }
        return false;
    }

    public function create() {
        $query = 'INSERT INTO ' . $this->table . ' 
            SET 
                trainer_id = :trainer_id,
                session_type = :session_type,
                activity_type = :activity_type,
                max_participants = :max_participants,
                start_time = :start_time,
                end_time = :end_time,
                location = :location,
                status = :status,
                notes = :notes';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->trainer_id = htmlspecialchars(strip_tags($this->trainer_id));
        $this->session_type = htmlspecialchars(strip_tags($this->session_type));
        $this->activity_type = htmlspecialchars(strip_tags($this->activity_type));
        $this->max_participants = htmlspecialchars(strip_tags($this->max_participants));
        $this->start_time = htmlspecialchars(strip_tags($this->start_time));
        $this->end_time = htmlspecialchars(strip_tags($this->end_time));
        $this->location = htmlspecialchars(strip_tags($this->location));
        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->notes = htmlspecialchars(strip_tags($this->notes));

        // Bind data
        $stmt->bindParam(':trainer_id', $this->trainer_id);
        $stmt->bindParam(':session_type', $this->session_type);
        $stmt->bindParam(':activity_type', $this->activity_type);
        $stmt->bindParam(':max_participants', $this->max_participants);
        $stmt->bindParam(':start_time', $this->start_time);
        $stmt->bindParam(':end_time', $this->end_time);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':notes', $this->notes);

        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function update() {
        $query = 'UPDATE ' . $this->table . ' 
            SET 
                trainer_id = :trainer_id,
                session_type = :session_type,
                activity_type = :activity_type,
                max_participants = :max_participants,
                start_time = :start_time,
                end_time = :end_time,
                location = :location,
                status = :status,
                notes = :notes
            WHERE session_id = :session_id';