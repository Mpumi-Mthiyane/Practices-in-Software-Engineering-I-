<?php
class Payment {
    private $conn;
    private $table = 'payments';

    public $payment_id;
    public $member_id;
    public $amount;
    public $payment_method;
    public $payment_date;
    public $period_start;
    public $period_end;
    public $receipt_number;
    public $recorded_by;
    public $notes;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = 'SELECT 
            p.payment_id, 
            p.member_id, 
            m.first_name, 
            m.last_name,
            p.amount, 
            p.payment_method, 
            p.payment_date, 
            p.period_start, 
            p.period_end, 
            p.receipt_number, 
            p.notes
        FROM ' . $this->table . ' p
        LEFT JOIN members m ON p.member_id = m.member_id
        ORDER BY p.payment_date DESC';

        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single() {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE payment_id = ? LIMIT 1';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->payment_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row) {
            $this->member_id = $row['member_id'];
            $this->amount = $row['amount'];
            $this->payment_method = $row['payment_method'];
            $this->payment_date = $row['payment_date'];
            $this->period_start = $row['period_start'];
            $this->period_end = $row['period_end'];
            $this->receipt_number = $row['receipt_number'];
            $this->recorded_by = $row['recorded_by'];
            $this->notes = $row['notes'];
            return true;
        }
        return false;
    }

    public function create() {
        $query = 'INSERT INTO ' . $this->table . ' 
            SET 
                member_id = :member_id,
                amount = :amount,
                payment_method = :payment_method,
                payment_date = :payment_date,
                period_start = :period_start,
                period_end = :period_end,
                receipt_number = :receipt_number,
                recorded_by = :recorded_by,
                notes = :notes';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->member_id = htmlspecialchars(strip_tags($this->member_id));
        $this->amount = htmlspecialchars(strip_tags($this->amount));
        $this->payment_method = htmlspecialchars(strip_tags($this->payment_method));
        $this->payment_date = htmlspecialchars(strip_tags($this->payment_date));
        $this->period_start = htmlspecialchars(strip_tags($this->period_start));
        $this->period_end = htmlspecialchars(strip_tags($this->period_end));
        $this->receipt_number = htmlspecialchars(strip_tags($this->receipt_number));
        $this->recorded_by = htmlspecialchars(strip_tags($this->recorded_by));
        $this->notes = htmlspecialchars(strip_tags($this->notes));

        // Bind data
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':amount', $this->amount);
        $stmt->bindParam(':payment_method', $this->payment_method);
        $stmt->bindParam(':payment_date', $this->payment_date);
        $stmt->bindParam(':period_start', $this->period_start);
        $stmt->bindParam(':period_end', $this->period_end);
        $stmt->bindParam(':receipt_number', $this->receipt_number);
        $stmt->bindParam(':recorded_by', $this->recorded_by);
        $stmt->bindParam(':notes', $this->notes);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function update() {
        $query = 'UPDATE ' . $this->table . ' 
            SET 
                member_id = :member_id,
                amount = :amount,
                payment_method = :payment_method,
                payment_date = :payment_date,
                period_start = :period_start,
                period_end = :period_end,
                receipt_number = :receipt_number,
                recorded_by = :recorded_by,
                notes = :notes
            WHERE payment_id = :payment_id';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->member_id = htmlspecialchars(strip_tags($this->member_id));
        $this->amount = htmlspecialchars(strip_tags($this->amount));
        $this->payment_method = htmlspecialchars(strip_tags($this->payment_method));
        $this->payment_date = htmlspecialchars(strip_tags($this->payment_date));
        $this->period_start = htmlspecialchars(strip_tags($this->period_start));
        $this->period_end = htmlspecialchars(strip_tags($this->period_end));
        $this->receipt_number = htmlspecialchars(strip_tags($this->receipt_number));
        $this->recorded_by = htmlspecialchars(strip_tags($this->recorded_by));
        $this->notes = htmlspecialchars(strip_tags($this->notes));
        $this->payment_id = htmlspecialchars(strip_tags($this->payment_id));

        // Bind data
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':amount', $this->amount);
        $stmt->bindParam(':payment_method', $this->payment_method);
        $stmt->bindParam(':payment_date', $this->payment_date);
        $stmt->bindParam(':period_start', $this->period_start);
        $stmt->bindParam(':period_end', $this->period_end);
        $stmt->bindParam(':receipt_number', $this->receipt_number);
        $stmt->bindParam(':recorded_by', $this->recorded_by);
        $stmt->bindParam(':notes', $this->notes);
        $stmt->bindParam(':payment_id', $this->payment_id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = 'DELETE FROM ' . $this->table . ' WHERE payment_id = :payment_id';
        $stmt = $this->conn->prepare($query);
        $this->payment_id = htmlspecialchars(strip_tags($this->payment_id));
        $stmt->bindParam(':payment_id', $this->payment_id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function get_by_member($member_id) {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE member_id = ? ORDER BY payment_date DESC';
        $stmt = $this->conn->prepare($query);
        $member_id = htmlspecialchars(strip_tags($member_id));
        $stmt->bindParam(1, $member_id);
        $stmt->execute();
        return $stmt;
    }

    public function get_by_date_range($start_date, $end_date) {
        $query = 'SELECT 
            p.payment_id, 
            p.member_id, 
            m.first_name, 
            m.last_name,
            p.amount, 
            p.payment_method, 
            p.payment_date, 
            p.period_start, 
            p.period_end, 
            p.receipt_number, 
            p.notes
        FROM ' . $this->table . ' p
        LEFT JOIN members m ON p.member_id = m.member_id
        WHERE p.payment_date BETWEEN ? AND ?
        ORDER BY p.payment_date DESC';

        $stmt = $this->conn->prepare($query);
        $start_date = htmlspecialchars(strip_tags($start_date));
        $end_date = htmlspecialchars(strip_tags($end_date));
        $stmt->bindParam(1, $start_date);
        $stmt->bindParam(2, $end_date);
        $stmt->execute();
        return $stmt;
    }
}
?>