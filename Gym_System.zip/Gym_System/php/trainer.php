<?php
class Trainer {
    private $conn;
    private $table = 'trainers';

    public $trainer_id;
    public $first_name;
    public $last_name;
    public $specialization;
    public $email;
    public $phone;
    public $certification;
    public $bio;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function read() {
        $query = 'SELECT * FROM ' . $this->table . ' ORDER BY last_name, first_name';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    public function read_single() {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE trainer_id = ? LIMIT 1';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(1, $this->trainer_id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if($row) {
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->specialization = $row['specialization'];
            $this->email = $row['email'];
            $this->phone = $row['phone'];
            $this->certification = $row['certification'];
            $this->bio = $row['bio'];
            $this->status = $row['status'];
            return true;
        }
        return false;
    }

    public function create() {
        $query = 'INSERT INTO ' . $this->table . ' 
            SET 
                first_name = :first_name,
                last_name = :last_name,
                specialization = :specialization,
                email = :email,
                phone = :phone,
                certification = :certification,
                bio = :bio,
                status = :status';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->first_name = htmlspecialchars(strip_tags($this->first_name));
        $this->last_name = htmlspecialchars(strip_tags($this->last_name));
        $this->specialization = htmlspecialchars(strip_tags($this->specialization));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->certification = htmlspecialchars(strip_tags($this->certification));
        $this->bio = htmlspecialchars(strip_tags($this->bio));
        $this->status = htmlspecialchars(strip_tags($this->status));

        // Bind data
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':specialization', $this->specialization);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':certification', $this->certification);
        $stmt->bindParam(':bio', $this->bio);
        $stmt->bindParam(':status', $this->status);

        if($stmt->execute()) {
            return $this->conn->lastInsertId();
        }
        return false;
    }

    public function update() {
        $query = 'UPDATE ' . $this->table . ' 
            SET 
                first_name = :first_name,
                last_name = :last_name,
                specialization = :specialization,
                email = :email,
                phone = :phone,
                certification = :certification,
                bio = :bio,
                status = :status
            WHERE trainer_id = :trainer_id';

        $stmt = $this->conn->prepare($query);

        // Clean data
        $this->first_name = htmlspecialchars(strip_tags($this->first_name));
        $this->last_name = htmlspecialchars(strip_tags($this->last_name));
        $this->specialization = htmlspecialchars(strip_tags($this->specialization));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->phone = htmlspecialchars(strip_tags($this->phone));
        $this->certification = htmlspecialchars(strip_tags($this->certification));
        $this->bio = htmlspecialchars(strip_tags($this->bio));
        $this->status = htmlspecialchars(strip_tags($this->status));
        $this->trainer_id = htmlspecialchars(strip_tags($this->trainer_id));

        // Bind data
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':specialization', $this->specialization);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':certification', $this->certification);
        $stmt->bindParam(':bio', $this->bio);
        $stmt->bindParam(':status', $this->status);
        $stmt->bindParam(':trainer_id', $this->trainer_id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function delete() {
        $query = 'DELETE FROM ' . $this->table . ' WHERE trainer_id = :trainer_id';
        $stmt = $this->conn->prepare($query);
        $this->trainer_id = htmlspecialchars(strip_tags($this->trainer_id));
        $stmt->bindParam(':trainer_id', $this->trainer_id);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function get_by_specialization($specialization) {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE FIND_IN_SET(?, specialization) > 0 AND status = "Active" ORDER BY last_name, first_name';
        $stmt = $this->conn->prepare($query);
        $specialization = htmlspecialchars(strip_tags($specialization));
        $stmt->bindParam(1, $specialization);
        $stmt->execute();
        return $stmt;
    }
}
?>